package com.sp.madproposal.Fragment;

import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.sp.madproposal.Model.AppUsageTracker;
import com.sp.madproposal.R;

import org.w3c.dom.Text;


public class AppUsageFragment extends Fragment {


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_app_usage, container, false);

        if (AppUsageTracker.hasUsageStatsPermission(requireContext())) {
            long usageTime = AppUsageTracker.getUsageTime(requireContext(), "com.sp.madproposal");
            String appName = AppUsageTracker.getAppName(requireContext(), "com.sp.madproposal");

            TextView appUsageTextView = view.findViewById(R.id.appUsageTextView);
            appUsageTextView.setText("App Name: " + appName + "\nUsage Time: " + usageTime + " milliseconds");
        } else {
            // Request permission or show a message to the user
        }

        return view;
    }
}