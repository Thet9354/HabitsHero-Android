package com.sp.madproposal.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.sp.madproposal.Model.Habit;
import com.sp.madproposal.R;

import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder>{

    private List<Habit> habitList;

    public HistoryAdapter(List<Habit> habitList) {
        this.habitList = habitList;
    }

    @NonNull
    @Override
    public HistoryAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_history_task, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryAdapter.ViewHolder holder, int position) {
        Habit habit = habitList.get(position);
        holder.txtView_taskName.setText(habit.getHabitName());
        holder.txtView_taskDate.setText(habit.getDateTime());
    }

    @Override
    public int getItemCount() {
        return habitList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView txtView_taskName;
        public TextView txtView_taskDate;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtView_taskName = itemView.findViewById(R.id.txtView_taskName);
            txtView_taskDate = itemView.findViewById(R.id.txtView_taskDate);
        }
    }
}
