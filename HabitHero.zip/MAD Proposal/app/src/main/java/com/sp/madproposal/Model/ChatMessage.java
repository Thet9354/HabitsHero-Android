package com.sp.madproposal.Model;

public class ChatMessage {
    public String senderId, receiverId, message, dateTime;
}
