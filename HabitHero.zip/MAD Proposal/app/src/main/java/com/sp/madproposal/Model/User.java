package com.sp.madproposal.Model;

import java.io.Serializable;

public class User implements Serializable {
    public String name, email, token;


}
