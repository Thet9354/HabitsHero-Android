package com.sp.madproposal.listeners;

import com.sp.madproposal.Model.User;

public interface UserListener {

    void onUserClicked(User user);
}
