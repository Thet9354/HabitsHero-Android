package com.sp.madproposal.Model;

public class Task {



}
